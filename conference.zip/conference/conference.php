<!DOCTYPE html>
<html>
<head>
    <title>Conference Administrators' Portal</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Conference 2025 Management System</h1>
    <img src="images/banner.jpg" width="600" alt="Conference Banner">

    <ul>
    <li><a href="pages/view_committee.php">View Committee Members</a></li>
    <li><a href="pages/hotel_students.php">View Students in a Hotel Room</a></li>
    <li><a href="pages/schedule.php">View Conference Schedule</a></li>
    <li><a href="pages/list_sponsors.php">List Sponsors</a></li>
    <li><a href="pages/company_jobs.php">Jobs</a></li>
    <li><a href="pages/attendees.php">All Attendees</a></li>
    <li><a href="pages/add_attendee.php">Add Attendee</a></li>
    <li><a href="pages/add_sponsor.php">Add Sponsor</a></li>
    <li><a href="pages/delete_sponsor.php">Delete Sponsor</a></li>
    <li><a href="pages/income_report.php">Total Conference Intake</a></li>
    <li><a href="pages/switch_session.php">Update Session</a></li>
</ul>
<footer style="margin-top: 120px; font-size: 14px; text-align: right; color: #333;">
        <p><strong>CISC332 - Database Management Systems (W25) Project</strong></p>
        <p>James Choi</p>
    </footer>
</body>
</html>