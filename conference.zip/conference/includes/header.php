<!DOCTYPE html>
<html>
<head>
    <title>Conference Management</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>University Conference Management System</h1>
    <hr>