<?php
require_once '../includes/db.php';

$submitted = isset($_POST['submitted']);
$message = "";

if ($submitted && !empty($_POST['company_name']) && !empty($_POST['level'])) {
    $company_name = $_POST['company_name'];
    $level = $_POST['level'];

    try {
        $stmt = $pdo->prepare("INSERT INTO Sponsor (company_name, level) VALUES (?, ?)");
        $stmt->execute([$company_name, $level]);
        $message = "✅ Sponsor added successfully.";
    } catch (PDOException $e) {
        $message = "❌ Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Sponsor</title>
</head>
<body>
    <h2>Add a New Sponsor</h2>

    <?php if ($message): ?>
        <p><strong><?= $message ?></strong></p>
    <?php endif; ?>

    <form method="post" action="add_sponsor.php">
        <input type="hidden" name="submitted" value="1">
        <label>Company Name: <input type="text" name="company_name" required></label><br>
        <label>Sponsorship Level:
            <select name="level" required>
                <option value="">-- Select Level --</option>
                <option value="Gold">Gold</option>
                <option value="Silver">Silver</option>
                <option value="Bronze">Bronze</option>
            </select>
        </label><br>
        <input type="submit" value="Add Sponsor">
    </form>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
