<?php
require_once '../includes/db.php';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Conference Attendees</title>
</head>

<body>
    <h2>Attendee Lists</h2>

    <!-- Students -->
    <h3>Student Attendees</h3>
    <?php
    $students = $pdo->query("SELECT name, student_number, department FROM Student ORDER BY name")->fetchAll();
    if ($students):
        ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Name</th>
                <th>Student Number</th>
                <th>Department</th>
            </tr>
            <?php foreach ($students as $s): ?>
                <tr>
                    <td><?= htmlspecialchars($s['name']) ?></td>
                    <td><?= htmlspecialchars($s['student_number']) ?></td>
                    <td><?= htmlspecialchars($s['department']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No student attendees found.</p>
    <?php endif; ?>


    <!-- Professionals -->
    <h3>Professional Attendees</h3>
    <?php
    $pros = $pdo->query("SELECT name, email FROM ProfessionalAttendee ORDER BY name")->fetchAll();
    if ($pros):
        ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Name</th>
                <th>Email</th>
            </tr>
            <?php foreach ($pros as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= htmlspecialchars($p['email']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No professional attendees found.</p>
    <?php endif; ?>

    <!-- Sponsors -->
    <h3>Sponsor Companies</h3>
    <?php
    $sponsors = $pdo->query("SELECT company_name, level FROM Sponsor ORDER BY level DESC, company_name")->fetchAll();
    if ($sponsors):
        ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Company Name</th>
                <th>Level</th>
            </tr>
            <?php foreach ($sponsors as $s): ?>
                <tr>
                    <td><?= htmlspecialchars($s['company_name']) ?></td>
                    <td><?= htmlspecialchars($s['level']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No sponsor companies found.</p>
    <?php endif; ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>

</html>