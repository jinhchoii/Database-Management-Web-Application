<?php
require_once '../includes/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>List of Sponsors</title>
</head>
<body>
    <h2>Sponsoring Companies</h2>

    <?php
    $stmt = $pdo->query("SELECT company_name, level FROM Sponsor ORDER BY level DESC, company_name ASC");
    $sponsors = $stmt->fetchAll();

    if ($sponsors):
    ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Company Name</th>
                <th>Sponsorship Level</th>
            </tr>
            <?php foreach ($sponsors as $sponsor): ?>
                <tr>
                    <td><?= htmlspecialchars($sponsor['company_name']) ?></td>
                    <td><?= htmlspecialchars($sponsor['level']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No sponsors found in the database.</p>
    <?php endif; ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
