<?php
require_once '../includes/db.php';

$selected_id = $_GET['sponsor_id'] ?? null;
$jobs = [];
$sponsor_name = "";

if ($selected_id) {
    $stmt = $pdo->prepare("
        SELECT s.company_name, j.title, j.description
        FROM Job j
        JOIN Sponsor s ON j.sponsor_id = s.sponsor_id
        WHERE s.sponsor_id = ?
    ");
    $stmt->execute([$selected_id]);
    $jobs = $stmt->fetchAll();

    if ($jobs) {
        $sponsor_name = $jobs[0]['company_name'];
    }
} else {
    // Show all jobs
    $stmt = $pdo->query("
        SELECT s.company_name, j.title, j.description
        FROM Job j
        JOIN Sponsor s ON j.sponsor_id = s.sponsor_id
        ORDER BY s.company_name, j.title
    ");
    $jobs = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Filter Jobs by Sponsor</title>
</head>
<body>
    <h2>All Jobs<?= $sponsor_name ? " at $sponsor_name" : "" ?></h2>

    <form method="get" action="company_jobs.php">
        <label>Filter by Sponsor:
            <select name="sponsor_id" onchange="this.form.submit()">
                <option value="">-- Show All --</option>
                <?php
                $sponsors = $pdo->query("SELECT sponsor_id, company_name FROM Sponsor ORDER BY company_name")->fetchAll();
                foreach ($sponsors as $s) {
                    $selected = ($selected_id == $s['sponsor_id']) ? 'selected' : '';
                    echo "<option value='{$s['sponsor_id']}' $selected>" . htmlspecialchars($s['company_name']) . "</option>";
                }
                ?>
            </select>
        </label>
    </form>

    <br>

    <?php if ($jobs): ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Company</th>
                <th>Job Title</th>
                <th>Description</th>
            </tr>
            <?php foreach ($jobs as $job): ?>
                <tr>
                    <td><?= htmlspecialchars($job['company_name']) ?></td>
                    <td><?= htmlspecialchars($job['title']) ?></td>
                    <td><?= htmlspecialchars($job['description']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No jobs found<?= $sponsor_name ? " for $sponsor_name." : "." ?></p>
    <?php endif; ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
