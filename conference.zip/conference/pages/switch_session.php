<?php
require_once '../includes/db.php';

$message = "";

// Handle form submission
if (isset($_POST['submitted']) && !empty($_POST['session_id'])) {
    $session_id = $_POST['session_id'];
    $new_date = $_POST['date'];
    $new_time = $_POST['time'];
    $new_room_id = $_POST['room_id'];

    try {
        $stmt = $pdo->prepare("UPDATE Session SET date = ?, time = ?, room_id = ? WHERE session_id = ?");
        $stmt->execute([$new_date, $new_time, $new_room_id, $session_id]);
        $message = "✅ Session updated successfully.";
    } catch (PDOException $e) {
        $message = "❌ Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Session</title>
</head>
<body>
    <h2>Update Session Time or Location</h2>

    <?php if ($message): ?>
        <p><strong><?= htmlspecialchars($message) ?></strong></p>
    <?php endif; ?>

    <form method="post" action="switch_session.php">
        <input type="hidden" name="submitted" value="1">

        <label>Select Session:
            <select name="session_id" required>
                <option value="">-- Select Session --</option>
                <?php
                $sessions = $pdo->query("
                    SELECT s.session_id, s.name AS session_name, c.name AS conf_name
                    FROM Session s
                    JOIN Conference c ON s.conference_id = c.conference_id
                    ORDER BY s.date, s.time
                ")->fetchAll();

                foreach ($sessions as $s) {
                    $label = htmlspecialchars("{$s['conf_name']} - {$s['session_name']}");
                    echo "<option value='{$s['session_id']}'>$label</option>";
                }
                ?>
            </select>
        </label><br><br>

        <label>New Date: <input type="date" name="date" required></label><br>
        <label>New Time: <input type="time" name="time" required></label><br>

        <label>New Location:
            <select name="room_id" required>
                <option value="">-- Select Location --</option>
                <?php
                $rooms = $pdo->query("SELECT room_id, room_number, capacity FROM ConferenceRoom")->fetchAll();
                foreach ($rooms as $r) {
                    $label = htmlspecialchars("{$r['room_number']} (Cap: {$r['capacity']})");
                    echo "<option value='{$r['room_id']}'>$label</option>";
                }
                ?>
            </select>
        </label><br><br>

        <input type="submit" value="Update Session">
    </form>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
