<?php
require_once '../includes/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Conference Schedule by Date</title>
</head>
<body>
    <h2>Select a Date to View the Schedule</h2>

    <form method="get">
        <label for="date">Date:</label>
        <select name="date" id="date">
            <option value="">-- Select Date --</option>
            <?php
            $dates = $pdo->query("SELECT DISTINCT date FROM Session ORDER BY date")->fetchAll();
            foreach ($dates as $d) {
                $dateStr = htmlspecialchars($d['date']);
                echo "<option value=\"$dateStr\">$dateStr</option>";
            }
            ?>
        </select>
        <input type="submit" value="View Schedule">
    </form>

    <?php
    if (!empty($_GET['date'])) {
        $selectedDate = $_GET['date'];

        $stmt = $pdo->prepare("
            SELECT 
                s.name AS session_name,
                s.time,
                s.start_end,
                cr.room_number AS location,
                c.name AS conference_name
            FROM Session s
            JOIN Conference c ON s.conference_id = c.conference_id
            LEFT JOIN ConferenceRoom cr ON s.room_id = cr.room_id
            WHERE s.date = ?
            ORDER BY s.time;
        ");
        $stmt->execute([$selectedDate]);
        $sessions = $stmt->fetchAll();

        echo "<h3>Sessions on $selectedDate:</h3>";
        if ($sessions) {
            echo "<table border='1' cellpadding='6'>";
            echo "<tr><th>Time</th><th>Session</th><th>Location</th><th>Conference</th></tr>";

            foreach ($sessions as $session) {
                // Format start time as AM/PM
                $start = new DateTime($session['time']);
                $formattedTime = $start->format('g:i A');

                echo "<tr>";
                echo "<td>" . htmlspecialchars($formattedTime) . "</td>";
                echo "<td>" . htmlspecialchars($session['session_name']) . "</td>";
                echo "<td>" . htmlspecialchars($session['location']) . "</td>";
                echo "<td>" . htmlspecialchars($session['conference_name']) . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No sessions scheduled for this day.</p>";
        }
    }
    ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
