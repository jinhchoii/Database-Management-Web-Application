<?php
require_once '../includes/db.php';

$message = "";

// Handle delete
if (isset($_POST['submitted']) && !empty($_POST['sponsor_id'])) {
    $sponsor_id = $_POST['sponsor_id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM Sponsor WHERE sponsor_id = ?");
        $stmt->execute([$sponsor_id]);
        $message = "✅ Sponsor deleted successfully.";
    } catch (PDOException $e) {
        $message = "❌ Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Sponsor</title>
</head>
<body>
    <h2>Delete Sponsor</h2>

    <?php if ($message): ?>
        <p><strong><?= $message ?></strong></p>
    <?php endif; ?>

    <form method="post" action="delete_sponsor.php">
        <input type="hidden" name="submitted" value="1">
        <label>Select Sponsor:
            <select name="sponsor_id" required>
                <option value="">-- Select Sponsor --</option>
                <?php
                $sponsors = $pdo->query("SELECT sponsor_id, company_name FROM Sponsor ORDER BY company_name")->fetchAll();
                foreach ($sponsors as $sponsor) {
                    $id = $sponsor['sponsor_id'];
                    $name = htmlspecialchars($sponsor['company_name']);
                    echo "<option value='$id'>$name</option>";
                }
                ?>
            </select>
        </label><br><br>
        <input type="submit" value="Delete Sponsor">
    </form>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
