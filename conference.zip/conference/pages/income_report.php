<?php
require_once '../includes/db.php';

define('STUDENT_FEE', 100);
define('SPONSOR_RATES', [
    'Gold' => 1000,
    'Silver' => 500,
    'Bronze' => 250
]);

// Count students
$studentCount = $pdo->query("SELECT COUNT(*) FROM Student")->fetchColumn();
$studentIncome = $studentCount * STUDENT_FEE;

// Count sponsors by level
$sponsorTotals = [
    'Gold' => 0,
    'Silver' => 0,
    'Bronze' => 0
];

foreach (SPONSOR_RATES as $level => $amount) {
    $count = $pdo->prepare("SELECT COUNT(*) FROM Sponsor WHERE level = ?");
    $count->execute([$level]);
    $sponsorTotals[$level] = $count->fetchColumn() * $amount;
}

$sponsorIncome = array_sum($sponsorTotals);
$grandTotal = $studentIncome + $sponsorIncome;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Total Conference Intake</title>
</head>
<body>
    <h2>Conference Income Report</h2>

    <table border="1" cellpadding="6">
        <tr>
            <th>Source</th>
            <th>Amount ($)</th>
        </tr>
        <tr>
            <td>Student Registration (<?= $studentCount ?> × $<?= STUDENT_FEE ?>)</td>
            <td><?= $studentIncome ?></td>
        </tr>
        <?php foreach ($sponsorTotals as $level => $amount): ?>
            <tr>
                <td><?= $level ?> Sponsorship (<?= SPONSOR_RATES[$level] ?> × <?= $amount / SPONSOR_RATES[$level] ?>)</td>
                <td><?= $amount ?></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th>Total Intake</th>
            <th><?= $grandTotal ?></th>
        </tr>
    </table>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
