<?php
require_once '../includes/db.php';

$attendee_type = $_POST['attendee_type'] ?? '';
$submitted = $_POST['submitted'] ?? '';
$message = "";

if ($submitted === '1') {
    if (
        $attendee_type === 'student' &&
        !empty($_POST['name']) &&
        !empty($_POST['department']) &&
        !empty($_POST['student_number']) &&
        !empty($_POST['room_id'])
    ) {
        $name = $_POST['name'];
        $dept = $_POST['department'];
        $student_number = $_POST['student_number'];
        $room_id = $_POST['room_id'];

        try {
            $pdo->beginTransaction();

            // Insert student
            $stmt = $pdo->prepare("INSERT INTO Student (name, department, student_number) VALUES (?, ?, ?)");
            $stmt->execute([$name, $dept, $student_number]);
            $student_id = $pdo->lastInsertId();

            // Step 1: Get room capacity
            $checkCapacity = $pdo->prepare("SELECT capacity FROM HotelRoom WHERE room_id = ?");
            $checkCapacity->execute([$room_id]);
            $room = $checkCapacity->fetch();

            if ($room) {
                $capacity = $room['capacity'];

                // Step 2: Count current assignments
                $countStmt = $pdo->prepare("SELECT COUNT(*) FROM RoomAssignment WHERE hotel_room_id = ?");
                $countStmt->execute([$room_id]);
                $currentCount = $countStmt->fetchColumn();

                // Step 3: Check if room is full
                if ($currentCount >= $capacity) {
                    $pdo->rollBack();
                    $message = "❌ Cannot assign student — selected room is already full.";
                } else {
                    // Step 4: Assign student to room
                    $assign = $pdo->prepare("INSERT INTO RoomAssignment (student_id, hotel_room_id) VALUES (?, ?)");
                    $assign->execute([$student_id, $room_id]);

                    $pdo->commit();
                    $message = "✅ Student added and assigned to room successfully.";
                }
            } else {
                $pdo->rollBack();
                $message = "❌ Error: Selected room not found.";
            }

        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "❌ Error: " . $e->getMessage();
        }

    } elseif (
        $attendee_type === 'professional' &&
        !empty($_POST['name']) &&
        !empty($_POST['email'])
    ) {
        $name = $_POST['name'];
        $email = $_POST['email'];

        try {
            $stmt = $pdo->prepare("INSERT INTO ProfessionalAttendee (name, email) VALUES (?, ?)");
            $stmt->execute([$name, $email]);
            $message = "✅ Professional attendee added successfully.";
        } catch (PDOException $e) {
            $message = "❌ Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Attendee</title>
</head>
<body>
    <h2>Add a New Attendee</h2>

    <?php if ($message): ?>
        <p><strong><?= htmlspecialchars($message) ?></strong></p>
    <?php endif; ?>

    <!-- Form 1: Select attendee type -->
    <form method="post" action="add_attendee.php">
        <label>Attendee Type:
            <select name="attendee_type" onchange="this.form.submit()" required>
                <option value="">-- Select --</option>
                <option value="student" <?= $attendee_type === 'student' ? 'selected' : '' ?>>Student</option>
                <option value="professional" <?= $attendee_type === 'professional' ? 'selected' : '' ?>>Professional</option>
            </select>
        </label>
        <input type="hidden" name="submitted" value="0">
    </form>

    <br><br>

    <!-- Form 2: Student info -->
    <?php if ($attendee_type === 'student'): ?>
        <form method="post" action="add_attendee.php">
            <input type="hidden" name="attendee_type" value="student">
            <input type="hidden" name="submitted" value="1">

            <label>Name: <input type="text" name="name" required></label><br>
            <label>Department: <input type="text" name="department" required></label><br>
            <label>Student Number: <input type="text" name="student_number" required></label><br>

            <label>Hotel Room:
                <select name="room_id" required>
                    <option value="">-- Select Room --</option>
                    <?php
                    $rooms = $pdo->query("
                        SELECT hr.room_id, hr.hotel_name, hr.room_number, hr.capacity,
                        (SELECT COUNT(*) FROM RoomAssignment ra WHERE ra.hotel_room_id = hr.room_id) AS assigned
                        FROM HotelRoom hr
                    ")->fetchAll();

                    foreach ($rooms as $room) {
                        $label = "{$room['hotel_name']} - {$room['room_number']} (Capacity: {$room['capacity']}, Assigned: {$room['assigned']})";
                        $disabled = ($room['assigned'] >= $room['capacity']) ? 'disabled' : '';
                        echo "<option value='{$room['room_id']}' $disabled>" . htmlspecialchars($label) . "</option>";
                    }
                    ?>
                </select>
            </label><br>

            <input type="submit" value="Add Student">
        </form>

    <!-- Form 2: Professional info -->
    <?php elseif ($attendee_type === 'professional'): ?>
        <form method="post" action="add_attendee.php">
            <input type="hidden" name="attendee_type" value="professional">
            <input type="hidden" name="submitted" value="1">

            <label>Name: <input type="text" name="name" required></label><br>
            <label>Email: <input type="email" name="email" required></label><br>

            <input type="submit" value="Add Professional">
        </form>
    <?php endif; ?>

    <br><br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
