<?php
require_once '../includes/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Students in Hotel Room</title>
</head>
<body>
    <h2>Select a Hotel Room</h2>

    <form method="get">
        <label for="room_id">Room:</label>
        <select name="room_id" id="room_id">
            <option value="">-- Select Room --</option>
            <?php
            $rooms = $pdo->query("SELECT * FROM HotelRoom")->fetchAll();
            foreach ($rooms as $room) {
                $label = "{$room['hotel_name']} - {$room['room_number']} (Capacity: {$room['capacity']})";
                echo "<option value='{$room['room_id']}'>" . htmlspecialchars($label) . "</option>";
            }
            ?>
        </select>
        <input type="submit" value="View Students">
    </form>

    <?php
    if (!empty($_GET['room_id'])) {
        $room_id = $_GET['room_id'];

        // Get room details and count of students
        $stmt = $pdo->prepare("
            SELECT hr.hotel_name, hr.room_number, hr.capacity,
                   COUNT(ra.assignment_id) AS current_occupancy
            FROM HotelRoom hr
            LEFT JOIN RoomAssignment ra ON hr.room_id = ra.hotel_room_id
            WHERE hr.room_id = ?
            GROUP BY hr.room_id
        ");
        $stmt->execute([$room_id]);
        $roomInfo = $stmt->fetch();

        if ($roomInfo) {
            echo "<h3>Room: " . htmlspecialchars($roomInfo['hotel_name']) . " - " . htmlspecialchars($roomInfo['room_number']) . "</h3>";
            echo "<p>Occupancy: " . $roomInfo['current_occupancy'] . " / " . $roomInfo['capacity'] . "</p>";

            // Get list of students in the room
            $stmt = $pdo->prepare("
                SELECT s.name, s.department
                FROM RoomAssignment ra
                JOIN Student s ON ra.student_id = s.student_id
                WHERE ra.hotel_room_id = ?
            ");
            $stmt->execute([$room_id]);
            $students = $stmt->fetchAll();

            echo "<h4>Students in Room:</h4>";
            if ($students) {
                echo "<ul>";
                foreach ($students as $s) {
                    echo "<li>" . htmlspecialchars($s['name']) . " (" . htmlspecialchars($s['department']) . ")</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No students assigned to this room.</p>";
            }
        } else {
            echo "<p>Room not found.</p>";
        }
    }
    ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
