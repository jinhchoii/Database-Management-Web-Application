<?php
require_once '../includes/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Committee Members</title>
</head>
<body>
    <h2>Select a Committee</h2>

    <form method="get" action="view_committee.php">
        <label for="committee_id">Committee:</label>
        <select name="committee_id" id="committee_id" required>
            <option value="">-- Select Committee --</option>
            <?php
            $committees = $pdo->query("SELECT committee_id, name FROM Committee")->fetchAll();
            foreach ($committees as $committee) {
                $selected = (isset($_GET['committee_id']) && $_GET['committee_id'] == $committee['committee_id']) ? 'selected' : '';
                echo "<option value='{$committee['committee_id']}' $selected>" . htmlspecialchars($committee['name']) . "</option>";
            }
            ?>
        </select>
        <input type="submit" value="View Members">
    </form>

    <br>

    <?php
    if (isset($_GET['committee_id']) && $_GET['committee_id'] !== '') {
        $committee_id = $_GET['committee_id'];

        // Fetch committee name
        $stmtName = $pdo->prepare("SELECT name FROM Committee WHERE committee_id = ?");
        $stmtName->execute([$committee_id]);
        $committeeName = $stmtName->fetchColumn();

        if ($committeeName) {
            echo "<h3>" . htmlspecialchars($committeeName) . " Committee Members</h3>";

            // Fetch members
            $stmtMembers = $pdo->prepare("SELECT name, email FROM CommitteeMember WHERE committee_id = ?");
            $stmtMembers->execute([$committee_id]);
            $members = $stmtMembers->fetchAll();

            if ($members) {
                echo "<table border='1' cellpadding='6'>";
                echo "<tr><th>Name</th><th>Email</th></tr>";
                foreach ($members as $member) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($member['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($member['email']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No members found for this committee.</p>";
            }
        } else {
            echo "<p>Committee not found.</p>";
        }
    }
    ?>

    <br>
    <a href="../conference.php">← Back to Home</a>
</body>
</html>
